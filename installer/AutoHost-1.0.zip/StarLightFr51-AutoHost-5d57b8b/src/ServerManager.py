import subprocess
import os
import requests
import platform
import zipfile
import tarfile
import UserInfoHandler

#TODO: TO REFACTOR

class ServerManager:

    def __init__(self):
        self.user_info_handler = UserInfoHandler.UserInfoHandler()

    def get_java_version(self, version):
        print(f'\nSearching for Java {version}...')

        paths = [
            "C:/Program Files/Java", "C:/Program Files (x86)/Java",
            "C:/Program Files/Eclipse Adoptium", "C:/Program Files/Temurin",
            "C:/Program Files/Microsoft", "/usr/lib/jvm", "/Library/Java/JavaVirtualMachines"
        ]

        for base in paths:
            if not os.path.exists(base):
                continue
            try:
                for entry in os.listdir(base):
                    if version not in entry:
                        continue

                    java_path = os.path.join(base, entry, "bin", "java.exe" if platform.system() == "Windows" else "java")
                    if os.path.isfile(java_path):
                        try:
                            result = subprocess.run([java_path, "-version"], capture_output=True, text=True, timeout=5)
                            output = result.stderr + result.stdout

                            if '"17.' in output or 'version "17':
                                print(f'Java {version} found: {java_path}')
                                
                                version_check = subprocess.run([java_path, "-version"], capture_output=True, text=True)
                                print(f"Version detected: {version_check.stderr.split('\\n')[0]}")
                                return java_path
                        except:
                            continue
            except:
                continue

        if os.path.exists("java"):
            for entry in os.listdir("java"):
                if "jdk" in entry.lower():
                    java_home = os.path.join("java", entry)
                    if platform.system() == "Darwin":
                        java_home = os.path.join(java_home, "Contents", "Home")
                    java_path = os.path.join(java_home, "bin", "java.exe" if platform.system() == "Windows" else "java")
                    if os.path.isfile(java_path):
                        try:
                            result = subprocess.run([java_path, "-version"], capture_output=True, text=True, timeout=5)
                            output = result.stderr + result.stdout
                            if '"17.' in output or 'version "17' in output:
                                print(f"Java {version} found (local): {java_path}")
                                return java_path
                        except:
                            continue

        print(f"Downloading Java {version}...")
        system = platform.system()

        arch = "x64" if platform.machine() in ["AMD64", "x86_64"] else "aarch64"
        
        if system == "Windows":
            os_name, ext, exe = "windows", "zip", "bin/java.exe"
        elif system == "Linux":
            os_name, ext, exe = "linux", "tar.gz", "bin/java"
        else:
            os_name, ext, exe = "mac", "tar.gz", "bin/java"
        
        api_url = f"https://api.adoptium.net/v3/assets/latest/{version}/hotspot?os={os_name}&architecture={arch}&image_type=jdk"

        try:
            assets = requests.get(api_url).json()
            url = assets[0]["binary"]["package"]["link"]
            filename = assets[0]["binary"]["package"]["name"]
            
            os.makedirs("java", exist_ok=True)
            filepath = os.path.join("java", filename)
            
            print(f"Downloading of {filename}...")
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                total = int(r.headers.get('content-length', 0))
                downloaded = 0
                
                with open(filepath, 'wb') as f:
                    for chunk in r.iter_content(8192):
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total > 0:
                            percent = (downloaded / total) * 100
                            print(f"\rProgression: {percent:.1f}%", end='')
            
            print(f"\nExtracting...")
            if ext == "zip":
                with zipfile.ZipFile(filepath, 'r') as z:
                    z.extractall("java")
            else:
                with tarfile.open(filepath, 'r:gz') as t:
                    t.extractall("java")
            
            os.remove(filepath)
            
            for d in os.listdir("java"):
                if d.startswith("jdk"):
                    java_home = os.path.join("java", d)
                    if system == "Darwin":
                        java_home = os.path.join(java_home, "Contents", "Home")
                    java_path = os.path.join(java_home, exe)
                    if system != "Windows":
                        os.chmod(java_path, 0o755)
                    print(f"Java {version} installed: {java_path}")
                    return java_path
        except Exception as e:
            self.user_info_handler.show_error(e)
            #print(f"Error: {e}")
            return "java"

'''
def get_java17():
    """Trouve ou installe Java 17"""
    print("\n🔍 Recherche de Java 17...")
    
    # Chercher Java 17 installé
    paths = [
        "C:/Program Files/Java", "C:/Program Files (x86)/Java",
        "C:/Program Files/Eclipse Adoptium", "C:/Program Files/Temurin",
        "C:/Program Files/Microsoft", "/usr/lib/jvm", "/Library/Java/JavaVirtualMachines"
    ]
    
    for base in paths:
        if not os.path.exists(base):
            continue
        try:
            for entry in os.listdir(base):
                # Vérifier si le nom contient "17" ou "jdk-17"
                if "17" not in entry.lower():
                    continue
                    
                java_path = os.path.join(base, entry, "bin", "java.exe" if platform.system() == "Windows" else "java")
                if os.path.isfile(java_path):
                    try:
                        result = subprocess.run([java_path, "-version"], capture_output=True, text=True, timeout=5)
                        output = result.stderr + result.stdout
                        
                        # Vérifier que c'est bien Java 17
                        if '"17.' in output or 'version "17' in output:
                            print(f"✓ Java 17 trouvé: {java_path}")
                            
                            # Double vérification
                            version_check = subprocess.run([java_path, "-version"], capture_output=True, text=True)
                            print(f"   Version détectée: {version_check.stderr.split('\\n')[0]}")
                            return java_path
                    except:
                        continue
        except:
            continue
    
    # Chercher dans le dossier local ./java
    if os.path.exists("java"):
        for entry in os.listdir("java"):
            if "jdk" in entry.lower():
                java_home = os.path.join("java", entry)
                if platform.system() == "Darwin":
                    java_home = os.path.join(java_home, "Contents", "Home")
                java_path = os.path.join(java_home, "bin", "java.exe" if platform.system() == "Windows" else "java")
                if os.path.isfile(java_path):
                    try:
                        result = subprocess.run([java_path, "-version"], capture_output=True, text=True, timeout=5)
                        output = result.stderr + result.stdout
                        if '"17.' in output or 'version "17' in output:
                            print(f"✓ Java 17 trouvé (local): {java_path}")
                            return java_path
                    except:
                        continue
    
    # Installer Java 17
    print("📥 Installation de Java 17...")
    system = platform.system()
    arch = "x64" if platform.machine() in ["AMD64", "x86_64"] else "aarch64"
    
    if system == "Windows":
        os_name, ext, exe = "windows", "zip", "bin/java.exe"
    elif system == "Linux":
        os_name, ext, exe = "linux", "tar.gz", "bin/java"
    else:
        os_name, ext, exe = "mac", "tar.gz", "bin/java"
    
    api_url = f"https://api.adoptium.net/v3/assets/latest/17/hotspot?os={os_name}&architecture={arch}&image_type=jdk"
    
    try:
        assets = requests.get(api_url).json()
        url = assets[0]["binary"]["package"]["link"]
        filename = assets[0]["binary"]["package"]["name"]
        
        os.makedirs("java", exist_ok=True)
        filepath = os.path.join("java", filename)
        
        print(f"   Téléchargement de {filename}...")
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            total = int(r.headers.get('content-length', 0))
            downloaded = 0
            
            with open(filepath, 'wb') as f:
                for chunk in r.iter_content(8192):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        percent = (downloaded / total) * 100
                        print(f"\r   Progression: {percent:.1f}%", end='')
        
        print(f"\n   Extraction...")
        if ext == "zip":
            with zipfile.ZipFile(filepath, 'r') as z:
                z.extractall("java")
        else:
            with tarfile.open(filepath, 'r:gz') as t:
                t.extractall("java")
        
        os.remove(filepath)
        
        for d in os.listdir("java"):
            if d.startswith("jdk"):
                java_home = os.path.join("java", d)
                if system == "Darwin":
                    java_home = os.path.join(java_home, "Contents", "Home")
                java_path = os.path.join(java_home, exe)
                if system != "Windows":
                    os.chmod(java_path, 0o755)
                print(f"✓ Java 17 installé: {java_path}")
                return java_path
    except Exception as e:
        print(f"✗ Erreur: {e}")
        return "java"

def download_forge(mc_ver, forge_ver, dest="./"):
    """Télécharge Forge Installer"""
    url = f"https://maven.minecraftforge.net/net/minecraftforge/forge/{mc_ver}-{forge_ver}/forge-{mc_ver}-{forge_ver}-installer.jar"
    filename = f"forge-{mc_ver}-{forge_ver}-installer.jar"
    filepath = os.path.join(dest, filename)
    
    print(f"📥 Téléchargement Forge {mc_ver}-{forge_ver}...")
    try:
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            total = int(r.headers.get('content-length', 0))
            downloaded = 0
            
            with open(filepath, 'wb') as f:
                for chunk in r.iter_content(8192):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        percent = (downloaded / total) * 100
                        print(f"\r   Progression: {percent:.1f}% ({downloaded}/{total} octets)", end='')
        
        print(f"\n✓ Téléchargé: {filepath}")
        return filepath
    except Exception as e:
        print(f"\n✗ Erreur téléchargement: {e}")
        return None

def install_forge(installer_jar, server_dir):
    """Installe Forge"""
    os.makedirs(server_dir, exist_ok=True)
    
    # Copier le JAR dans le dossier serveur
    jar_name = os.path.basename(installer_jar)
    dest_jar = os.path.join(server_dir, jar_name)
    
    if installer_jar != dest_jar:
        import shutil
        shutil.copy(installer_jar, dest_jar)
        print(f"📦 Copie de l'installer dans {server_dir}")
    
    print(f"⚙️  Installation de Forge...")
    p = subprocess.run(
        [get_java17(), "-jar", jar_name, "--installServer"],
        cwd=server_dir,
        capture_output=True,
        text=True
    )
    
    print(p.stdout)
    
    if p.returncode == 0:
        print("✓ Forge installé avec succès")
        
        # Lister les fichiers créés
        print("\n📂 Fichiers dans le serveur:")
        for f in os.listdir(server_dir):
            size = os.path.getsize(os.path.join(server_dir, f))
            print(f"   - {f} ({size/1024/1024:.1f} MB)")
        
        return True
    print(f"✗ Erreur installation: {p.stderr}")
    return False

def accept_eula(server_dir):
    """Accepte l'EULA"""
    with open(os.path.join(server_dir, "eula.txt"), "w") as f:
        f.write("eula=true\n")
    print("✓ EULA accepté")

def find_forge_jar(server_dir):
    """Trouve le JAR Forge"""
    print(f"\n🔍 Recherche du JAR Forge dans {server_dir}...")
    
    if not os.path.exists(server_dir):
        print(f"✗ Le dossier {server_dir} n'existe pas")
        return None
    
    files = os.listdir(server_dir)
    print(f"   Fichiers trouvés: {len(files)}")
    
    # Chercher le JAR Forge
    for f in files:
        if f.endswith(".jar"):
            print(f"   - JAR trouvé: {f}")
            if f.startswith("forge") and "installer" not in f.lower():
                print(f"✓ JAR Forge sélectionné: {f}")
                return f
    
    # Chercher aussi les scripts run.sh/run.bat
    for f in files:
        if f in ["run.sh", "run.bat"]:
            print(f"✓ Script de lancement trouvé: {f}")
            return f
    
    print("✗ Aucun JAR Forge trouvé")
    print("   Forge a peut-être créé un fichier 'run.sh' ou 'run.bat'")
    return None

def start_server(server_dir, ram="4G"):
    """Démarre le serveur"""
    jar = find_forge_jar(server_dir)
    if not jar:
        return None
    
    java = get_java17()
    
    # VÉRIFICATION CRITIQUE : S'assurer que c'est bien Java 17
    print("\n⚠️  VÉRIFICATION JAVA...")
    try:
        check_result = subprocess.run([java, "-version"], capture_output=True, text=True, timeout=5)
        java_output = check_result.stderr + check_result.stdout
        print(f"   {java_output.split(chr(10))[0]}")
        
        if "version \"22" in java_output or "version \"21" in java_output or "version \"18" in java_output:
            print(f"   ✗ ERREUR: Mauvaise version Java détectée!")
            print(f"   ✗ Java 17 est requis, mais une autre version sera utilisée")
            print(f"   ✗ Le serveur ne démarrera pas correctement")
            
            # Essayer de forcer la variable d'environnement
            if platform.system() == "Windows":
                print("\n💡 Essayez manuellement:")
                print(f'   set JAVA_HOME={os.path.dirname(os.path.dirname(java))}')
                print(f'   set PATH=%JAVA_HOME%\\bin;%PATH%')
            return None
        
        if '"17.' in java_output or 'version "17' in java_output:
            print("   ✓ Java 17 confirmé!")
        else:
            print(f"   ⚠️  Version Java non confirmée comme 17")
            
    except Exception as e:
        print(f"   ✗ Impossible de vérifier Java: {e}")
    
    server_dir_abs = os.path.abspath(server_dir)
    
    # Si c'est un script
    if jar.endswith((".sh", ".bat")):
        print(f"\n🚀 Détection de script {jar}")
        
        # Sur Windows, ignorer les .sh et chercher le JAR directement
        if platform.system() == "Windows" and jar.endswith(".sh"):
            print("   ⚠️  Script .sh détecté sur Windows, recherche du JAR...")
            
            # Lire le script pour trouver le nom du JAR
            script_path = os.path.join(server_dir_abs, jar)
            try:
                with open(script_path, 'r') as f:
                    content = f.read()
                    # Chercher "java -jar XXX.jar"
                    import re
                    match = re.search(r'-jar\s+([^\s]+\.jar)', content)
                    if match:
                        real_jar = match.group(1)
                        # Extraire juste le nom du fichier
                        real_jar = os.path.basename(real_jar)
                        print(f"   ✓ JAR trouvé dans le script: {real_jar}")
                        jar = real_jar
                    else:
                        print("   ✗ Impossible de trouver le JAR dans le script")
                        return None
            except Exception as e:
                print(f"   ✗ Erreur lecture script: {e}")
                return None
        elif jar.endswith(".bat"):
            # Lancer le .bat sur Windows
            print(f"   Lancement du script batch...")
            cmd = [os.path.join(server_dir_abs, jar)]
        else:
            # .sh sur Linux/Mac
            script_path = os.path.join(server_dir_abs, jar)
            os.chmod(script_path, 0o755)
            cmd = ["bash", script_path]
    
    # Si c'est un JAR ou si on a extrait le JAR du script
    if jar.endswith(".jar"):
        print(f"\n🚀 Lancement du serveur...")
        print(f"   Java utilisé: {java}")
        print(f"   RAM: {ram}")
        print(f"   JAR: {jar}")
        print(f"   Dossier: {server_dir_abs}")
        
        cmd = [java, f"-Xms{ram}", f"-Xmx{ram}", "-jar", jar, "nogui"]
        print(f"\n📋 Commande complète:")
        print(f"   {' '.join(cmd)}")
    
    try:
        # Définir JAVA_HOME pour être sûr
        env = os.environ.copy()
        java_home = os.path.dirname(os.path.dirname(java))
        env['JAVA_HOME'] = java_home
        env['PATH'] = os.path.join(java_home, 'bin') + os.pathsep + env.get('PATH', '')
        
        print(f"\n🔧 Variables d'environnement:")
        print(f"   JAVA_HOME: {java_home}")
        
        p = subprocess.Popen(
            cmd,
            cwd=server_dir_abs,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=env  # IMPORTANT: Utiliser l'environnement modifié
        )
        print("\n✓ Serveur démarré\n")
        print("=" * 60)
        return p
    except Exception as e:
        print(f"✗ Erreur au lancement: {e}")
        return None

def send_cmd(process, cmd):
    """Envoie une commande"""
    if process and process.stdin:
        process.stdin.write(cmd + "\n")
        process.stdin.flush()

def read_logs(process):
    """Lit les logs"""
    if process and process.stdout:
        for line in process.stdout:
            print(line.strip())

# Exemple d'utilisation
if __name__ == "__main__":
    MC_VER = "1.20.1"
    FORGE_VER = "47.2.0"
    SERVER_DIR = "./serveur"
    
    print("=" * 60)
    print("🎮 Configuration Serveur Minecraft Forge")
    print("=" * 60)
    print(f"Version Minecraft: {MC_VER}")
    print(f"Version Forge: {FORGE_VER}")
    print(f"Dossier serveur: {SERVER_DIR}")
    print("=" * 60 + "\n")
    
    # 1. Télécharger et installer
    installer = download_forge(MC_VER, FORGE_VER, SERVER_DIR)
    
    if installer and install_forge(installer, SERVER_DIR):
        accept_eula(SERVER_DIR)
        
        # 2. Démarrer
        srv = start_server(SERVER_DIR, ram="4G")
        if srv:
            read_logs(srv)

'''