from tkinter import messagebox

class UserInfoHandler:
    def show_error(self, msg):
        messagebox.showerror("An Error Occured", msg)

    def show_warning(self, msg):
        messagebox.showwarning("Warning", msg)

    def show_info(self, msg):
        messagebox.showinfo("Info", msg)