import miniupnpc
import requests
import signal
import sys
import time
import DuckDNSManager
import UserInfoHandler

class UPnPManager:
    def __init__(self, port=0, description="UPnP Test", dns_info={}):
        self.port = port
        self.description = description
        self.upnp = miniupnpc.UPnP()
        self.mapped = False
        self.ext_ip = None
        self._setup_signal_handlers()
        self.duck_dns = None
        self.user_info_handler = UserInfoHandler.UserInfoHandler()
        if not dns_info == {} and dns_info["supported"] == True:
            self.duck_dns = DuckDNSManager.DuckDNSManager(dns_info["domain"], dns_info["token"])
        

    def _setup_signal_handlers(self):
        signal.signal(signal.SIGINT, self.cleanup)
        signal.signal(signal.SIGTERM, self.cleanup)

    def discover(self, timeout_ms=200):
        try:
            self.upnp.discoverdelay = timeout_ms
            n =self.upnp.discover()
            if n == 0:
                print("[UPNP] No UPnP device detected")
                return False
            
            self.upnp.selectigd()
            print(f"[UPNP] Gateway selected, public IP: {self.upnp.externalipaddress()}")
            return True
        except Exception as e:
            self.user_info_handler.show_error(e)
            print("[UPNP] Error discovered :", e)
            return False
        
    def get_external_ip(self):
        try:
            self.ext_ip = self.upnp.externalipaddress()
        except Exception:
            pass

        if not self.ext_ip:
            try:
                self.ext_ip = requests.get("https://ifconfig.co/ip", timeout=5).text.strip()
            except Exception:
                self.ext_ip = "Public IP unknown"
        return self.ext_ip
        
    def add_mapping(self):
        try:
            ok = self.upnp.addportmapping(self.port, "TCP", self.upnp.lanaddr, self.port, self.description, "")
            if ok:
                self.mapped = True
                print(f"[UPNP] Mapping added : {self.upnp.lanaddr}:{self.port} -> extern {self.get_external_ip()}:{self.port}")
            else:
                print("[UPNP] Impossible to add the mapping")
        except Exception as e:
            self.user_info_handler.show_error(e)
            print("[UPNP] Mapping Error :", e)

    def update_duckdns(self, ip):
        url = f"https://www.duckdns.org/update?domains={self.duck_domain}&token={self.duck_token}&ip={ip}"
        try:
            r = requests.get(url, timeout=5)
            if "OK" in r.text:
                print(f"[DuckDNS] IP updated : {ip}")
            else:
                print(f"[DuckDNS] Unexpected response: {r.text}")
        except Exception as e:
            self.user_info_handler.show_error(e)
            print("[DuckDNS] Error:", e)

    def delete_mapping(self):
        if self.mapped:
            try:
                self.upnp.deleteportmapping(self.port, "TCP")
                print(f"[UPNP] Mapping {self.port}/TCP deleted")
                self.mapped = False
            except Exception as e:
                self.user_info_handler.show_error(e)
                print("[UPNP] Error while deleting the mapping :", e)

    def cleanup(self, sig=None, frame=None):
        print("\n[UPNP] Cleaning...")
        self.delete_mapping()
        sys.exit(0)

    def show_ips(self):
        print(f"local IP : {self.upnp.lanaddr}:{self.port}")
        print(f"public IP : {self.get_external_ip()}:{self.port}")

    def run(self):
        if not self.discover():
            return
        self.add_mapping()

        if self.duck_dns == None:
            print("[INFO] DNS not supported")

        while True:
            ip = self.get_external_ip()
            if ip and ip != self.ext_ip:
                self.ext_ip = ip
                if not self.duck_dns == None:
                    self.duck_dns.update_duckdns(ip)
                print(f"[INFO] Players can connect via {self.duck_dns.duck_domain}.duckdns.org:{self.port}")
            time.sleep(1)

if __name__ == "__main__":
    port = 25565
    manager = UPnPManager(port, description="A Minecraft Server", dns_info={"supported": False}) #, "domain": "domain-name", "token": "account-token"})
    if manager.discover():
        manager.add_mapping()
        manager.show_ips()
        print("Ctrl+C for stop and delete the mapping")
        manager.run()