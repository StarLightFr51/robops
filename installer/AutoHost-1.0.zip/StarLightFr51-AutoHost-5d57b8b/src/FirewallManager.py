import subprocess
import UserInfoHandler

class FirewallManager:
    def __init__(self):
        self.user_info_handler = UserInfoHandler.UserInfoHandler()

    def allow_firewall_port(self, port, name="Minecraft Server"):
        path = r"src\Firewall\c_rule.mc.bat"
        try:
            parameters = f"{port} {name}"
            command = f'Start-Process "{path}" -ArgumentList "{parameters}" -Verb RunAs -WindowStyle Hidden'
            subprocess.run(["powershell", "-Command", command], shell=True)

            print(f"[Firewall] Port {port}/TCP autorized")
            self.user_info_handler.show_info(f"Port {port}/TCP autorized")
        except subprocess.CalledProcessError as e:
            self.user_info_handler.show_error(e)

    def remove_firewall_rule(self, name="Minecraft Server"):
        path = r"src\Firewall\d_rule.mc.bat"
        try:
            command = f'Start-Process "{path}" -ArgumentList "{name}" -Verb RunAs -WindowStyle Hidden'

            subprocess.run(["powershell", "-Command", command], shell=True)
        except Exception as e:
            self.user_info_handler.show_error(e)


if __name__ == "__main__":
    f = FirewallManager()

    f.allow_firewall_port(25565, "AUTOHOST_TEST_FIREWALL")