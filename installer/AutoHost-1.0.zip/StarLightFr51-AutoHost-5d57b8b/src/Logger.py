class Logger:
    def __init__(self, path):
        self.path = path

    def write(self, content):
        with open(self.path, 'a') as f:
            f.write(content) #add timestamp