@echo off

:: %1 = port
:: %2 = name of the rule

set PORT=%1
set RULENAME=%2

if "%PORT%"=="" set PORT=25565
if "%RULENAME%"=="" set RULENAME=AutoHostMinecraftServer

echo [Firewall] Adding rule "%RULENAME%" on port %PORT%...

netsh advfirewall firewall add rule name="%RULENAME%" ^ dir=in action=allow protocol=TCP localport=%PORT%

echo [OK] Rule added
pause