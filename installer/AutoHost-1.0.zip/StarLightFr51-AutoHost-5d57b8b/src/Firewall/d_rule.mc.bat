@echo off
:: %1 = Rule name

set RULENAME = %1
if "%RULENAME%"=="" set RULENAME=AutoHostMinecraftServer

echo [Firewall] Deleting rule: "%RULENAME%"...

netsh advfirewall firewall delete rule name=%RULENAME%
pause