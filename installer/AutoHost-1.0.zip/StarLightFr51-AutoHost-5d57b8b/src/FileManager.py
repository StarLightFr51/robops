import os

class FileManager:
    def __init__(self):
        self.appdata_path = os.getenv('APPDATA')
        self.create_folder()

    def create_appdata_folder(self):
        if not os.path.exists(os.path.join(self.appdata_path, "AutoHost")):
            os.makedirs("AutoHost")