import requests
import time
import UserInfoHandler

class DuckDNSManager:
    def __init__(self, duck_domain, duck_token):
        self.duck_domain = duck_domain
        self.duck_token = duck_token
        self.user_info_handler = UserInfoHandler.UserInfoHandler()

    def update_duckdns(self, ip):
        url = f"https://www.duckdns.org/update?domains={self.duck_domain}&token={self.duck_token}&ip={ip}"
        try:
            r = requests.get(url, timeout=5)
            if "OK" in r.text:
                print(f"[DuckDNS] IP updated : {ip}")
            else:
                print(f"[DuckDNS] Unexpected response: {r.text}")
        except Exception as e:
            self.user_info_handler.show_error(e)
            print("[DuckDNS] Error:", e)

